function CalculoQT() {
  const valorHora = parseFloat(document.getElementById("ValorHora").value);
  const horas = parseFloat(document.getElementById("horasTrabalhadas").value);
  const outrasDeducoes = parseFloat(document.getElementById("OutrasDeducoes").value || 0);
  const valeTransporte = document.querySelector('input[name="valeTransporte"]:checked')?.value === "Sim";

  if (!valorHora || valorHora === 0) {
    alert("Sistema finalizado.");
    return;
  }


  const salarioBruto = valorHora * horas;

  
  let inss = 0;
  if (salarioBruto <= 1320) {
    inss = salarioBruto * 0.075;
  } else if (salarioBruto <= 2571.29) {
    inss = salarioBruto * 0.09;
  } else if (salarioBruto <= 3856.94) {
    inss = salarioBruto * 0.12;
  } else {
    inss = salarioBruto * 0.14;
  }


  let irpf = 0;
  const baseIR = salarioBruto - inss;
  if (baseIR <= 2112) {
    irpf = 0;
  } else if (baseIR <= 2826.65) {
    irpf = baseIR * 0.075;
  } else if (baseIR <= 3751.05) {
    irpf = baseIR * 0.15;
  } else if (baseIR <= 4664.68) {
    irpf = baseIR * 0.225;
  } else {
    irpf = baseIR * 0.275;
  }

  const descontoVT = valeTransporte ? salarioBruto * 0.06 : 0;
  const salarioLiquido = salarioBruto - inss - irpf - descontoVT - outrasDeducoes;

  
  const resultado = `
    <strong>CÁLCULO TRABALHISTA</strong><br>
    Salário Bruto: R$ ${salarioBruto.toFixed(2)}<br>
    Desconto INSS: R$ ${inss.toFixed(2)}<br>
    Desconto IRPF: R$ ${irpf.toFixed(2)}<br>
    Desconto Vale Transporte: R$ ${descontoVT.toFixed(2)}<br>
    Outras Deduções: R$ ${outrasDeducoes.toFixed(2)}<br>
    <strong>Salário Líquido: R$ ${salarioLiquido.toFixed(2)}</strong>
  `;

  document.getElementById("resultado").innerHTML = resultado;
}
