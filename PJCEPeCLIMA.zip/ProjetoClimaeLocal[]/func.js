const API_KEY = "bafce804d5488115465277d53f910a58";

function coletarCEP() {
    const CEP = document.querySelector("#CEP").value.trim();
    if (CEP === "") {
        alert("Digite um CEP válido.");
        return;
    }
    receberDados(CEP);
}

async function receberDados(CEP) {
    try {
        const dados = await fetch(`https://viacep.com.br/ws/${CEP}/json/`).then(x => x.json());

        if (dados.erro) {
            alert("CEP não encontrado.");
            return;
        }

        dadosTela(dados);
        receberDadosClima(dados.localidade);
    } catch (erro) {
        console.error("Erro ao buscar o CEP:", erro);
        alert("Erro ao buscar o endereço.");
    }
}

function dadosTela(dados) {
    document.querySelector("#endereco").textContent = dados.logradouro || "-";
    document.querySelector("#bairro").textContent = dados.bairro || "-";
    document.querySelector("#cidade").textContent = dados.localidade || "-";
    document.querySelector("#estado").textContent = dados.uf || "-";
}

async function receberDadosClima(cidade) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(cidade)}&appid=${API_KEY}&units=metric&lang=pt_br`;

    try {
        const resposta = await fetch(url);
        const dados = await resposta.json();

        if (!resposta.ok) {
            alert(`Erro ao obter clima: ${dados.message}`);
            return;
        }

        document.querySelector("#temperatura").textContent = `${dados.main.temp.toFixed(1)} °C`;
        document.querySelector("#clima").textContent = dados.weather[0].description;
        document.querySelector("#umidade").textContent = `${dados.main.humidity} %`;
        document.querySelector("#vento").textContent = `${(dados.wind.speed * 3.6).toFixed(1)} km/h`;

        document.querySelector("#resultado").classList.remove("hidden");
    } catch (erro) {
        console.error("Erro ao buscar dados do clima:", erro);
        alert("Erro ao conectar com a API do clima.");
    }
}



