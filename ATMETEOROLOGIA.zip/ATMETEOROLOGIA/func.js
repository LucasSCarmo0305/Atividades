const API_KEY = "bafce804d5488115465277d53f910a58";


function coletarCidade() {
    const cidade = document.querySelector("#cidade").value.trim();
    if (cidade === "") {
        alert("Digite uma cidade válida.");
        return;
    }
    receberDadosClima(cidade);
}

async function receberDadosClima(cidade) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(cidade)}&appid=${API_KEY}&units=metric&lang=pt_br`;

    try {
        const resposta = await fetch(url);
        const dados = await resposta.json();

        if (!resposta.ok) {
            alert(`Erro: ${dados.message}`);
            return;
        }

        document.querySelector("#temperatura").textContent = `${dados.main.temp.toFixed(1)} °C`;
        document.querySelector("#clima").textContent = dados.weather[0].description;
        document.querySelector("#umidade").textContent = `${dados.main.humidity} %`;
        document.querySelector("#vento").textContent = `${(dados.wind.speed * 3.6).toFixed(1)} km/h`;

        document.querySelector("#resultado").classList.remove("hidden");

    } catch (erro) {
        console.error("Erro ao buscar dados:", erro);
        alert("Erro ao conectar com a API.");
    }
}
