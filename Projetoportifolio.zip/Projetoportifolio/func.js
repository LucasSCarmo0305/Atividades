function toggleCategoria(el) {
  const content = el.nextElementSibling;
  const arrow = el.querySelector(".seta");
  const isOpen = content.style.display === "block";

  content.style.display = isOpen ? "none" : "block";
  arrow.textContent = isOpen ? "▼" : "▲";
}


document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = form.querySelector("input[type='email']").value.trim();
    const mensagem = form.querySelector("textarea").value.trim();

    if (!email || !mensagem) {
      alert("Por favor, preencha todos os campos.");
      return;
    }

   
    alert("Mensagem enviada com sucesso!\n\nResumo:\nE-mail: " + email + "\nMensagem: " + mensagem);

    const numero = "5581999999999"; 
    const textoWhatsApp = `Olá! Um novo contato foi enviado pelo portfólio:\n\n📧 E-mail: ${email}\n💬 Mensagem: ${mensagem}`;
    const urlWhatsApp = `https://wa.me/${numero}?text=${encodeURIComponent(textoWhatsApp)}`;

    window.open(urlWhatsApp, "_blank");

 

    form.reset();
  });
});

function toggleTheme() {
  const body = document.body;
  const button = document.querySelector('.theme-toggle');
  
  body.classList.toggle('light-mode');

  if (body.classList.contains('light-mode')) {
    button.innerHTML = '<i class="fa-solid fa-sun"></i>';
  } else {
    button.innerHTML = '<i class="fa-solid fa-moon"></i>';
  }
}

