function calcularIMC() {

  let nome = document.getElementById("nomeCompleto").value;
  let peso = parseFloat(document.getElementById("peso").value);
  let altura = parseFloat(document.getElementById("altura").value);
  let sexo = document.getElementById("generoMasculino").checked ? "Masculino" : "Feminino";

  let imc = peso / (altura * altura);
  let condicao = "";

  
  if (sexo === "Feminino") {
    if (imc < 19.1) condicao = "Abaixo do peso";
    else if (imc <= 25.8) condicao = "No peso normal";
    else if (imc <= 27.3) condicao = "Marginalmente acima do peso";
    else if (imc <= 32.3) condicao = "Acima do peso ideal";
    else condicao = "Obeso";
  } else {
    if (imc < 20.7) condicao = "Abaixo do peso";
    else if (imc <= 26.4) condicao = "No peso normal";
    else if (imc <= 27.8) condicao = "Marginalmente acima do peso";
    else if (imc <= 31.1) condicao = "Acima do peso ideal";
    else condicao = "Obeso";
  }

  
  let resultado = document.getElementById("resultado");
  resultado.innerHTML = `
    <h2>Resultado</h2>
    <p><strong>Nome:</strong> ${nome}</p>
    <p><strong>Sexo:</strong> ${sexo}</p>
    <p><strong>Peso:</strong> ${peso} kg</p>
    <p><strong>Altura:</strong> ${altura} m</p>
    <p><strong>IMC:</strong> ${imc.toFixed(2)}</p>
    <p><strong>Condição:</strong> ${condicao}</p>
  `;
}
