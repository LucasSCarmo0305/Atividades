document.getElementById("formInscricao").addEventListener("submit", function (event) {

  event.preventDefault();

  let nomeCompleto = document.getElementById('nomeCompleto').value;
  let email = document.getElementById('email').value;
  let celular = document.getElementById('celular').value;


    let conclusao = `
      <p><strong>Nome Completo:</strong> ${nomeCompleto}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Celular:</strong> ${celular}</p>
    `;
    document.getElementById("conclusao").innerHTML = conclusao;


alert('Seus dados foram salvo');

  
});
