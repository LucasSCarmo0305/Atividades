function mensagem(num){

    window.alert('Voce clicou no botao '+ num,);
    
}




